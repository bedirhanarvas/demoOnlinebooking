package test.example.demo.room.domain.enums;

public enum RoomType {

	SINGLE,
	DOUBLE
	
}
