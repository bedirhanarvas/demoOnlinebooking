package test.example.demo.user.domain.enums;

public enum Role {
	
	USER,
	ADMIN

}
